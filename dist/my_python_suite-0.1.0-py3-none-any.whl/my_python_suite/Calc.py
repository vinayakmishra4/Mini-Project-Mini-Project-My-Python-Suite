# Calaulator Operation in Python
def additon(a,b):
    return a+b

def subtraction(a,b):
    return a-b

def multiplication(a,b):
    return a*b

def division(a,b):
    return a/b

def exponentiation(a,b):
    return a**b

def modulus(a,b):
    return a%b

def floor_division(a,b):
    return a//b

def Absolute_Value(a):
    return abs(a)

def sqaure_root(a):
    return a**0.5
