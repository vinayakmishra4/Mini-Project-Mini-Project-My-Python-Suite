# python_suite/__init__.py

from . import Calc
from . import unitconvert
from . import funfact

__version__ = "0.1.0"

__all__ = ["calc", "unitconvert", "funfact"]